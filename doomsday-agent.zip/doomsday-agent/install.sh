#!/usr/bin/env bash
# ☠️ DOOMSDAY Agent — Install Script
# Installs globally into ~/.claude/ so it's available in EVERY project

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLAUDE_DIR="$HOME/.claude"

echo "☠️  Installing DOOMSDAY agent globally..."

# Create directories
mkdir -p "$CLAUDE_DIR"/{agents,skills,commands}

# --- CLAUDE.md (global) ---
# Backup existing
if [ -f "$CLAUDE_DIR/CLAUDE.md" ]; then
  cp "$CLAUDE_DIR/CLAUDE.md" "$CLAUDE_DIR/CLAUDE.md.backup.$(date +%Y%m%d%H%M%S)"
  echo "⚠️  Backed up existing CLAUDE.md"
fi
cp "$SCRIPT_DIR/CLAUDE.md" "$CLAUDE_DIR/CLAUDE.md"
echo "✅ CLAUDE.md installed"

# --- Settings.json (global) ---
if [ -f "$CLAUDE_DIR/settings.json" ]; then
  cp "$CLAUDE_DIR/settings.json" "$CLAUDE_DIR/settings.json.backup.$(date +%Y%m%d%H%M%S)"
  echo "⚠️  Backed up existing settings.json"
fi
cp "$SCRIPT_DIR/.claude/settings.json" "$CLAUDE_DIR/settings.json"
echo "✅ settings.json installed"

# --- Agents ---
cp "$SCRIPT_DIR/.claude/agents/"*.md "$CLAUDE_DIR/agents/"
echo "✅ Agents installed: $(ls "$CLAUDE_DIR/agents/" | wc -l) agents"

# --- Skills ---
for skill_dir in "$SCRIPT_DIR/.claude/skills"/*/; do
  skill_name=$(basename "$skill_dir")
  mkdir -p "$CLAUDE_DIR/skills/$skill_name"
  cp "$skill_dir/SKILL.md" "$CLAUDE_DIR/skills/$skill_name/SKILL.md"
done
echo "✅ Skills installed: $(ls "$CLAUDE_DIR/skills/" | wc -l) skills"

# --- Commands ---
cp "$SCRIPT_DIR/.claude/commands/"*.md "$CLAUDE_DIR/commands/" 2>/dev/null || true
echo "✅ Commands installed: $(ls "$CLAUDE_DIR/commands/" 2>/dev/null | wc -l) commands"

echo ""
echo "☠️  DOOMSDAY installed. Launch with: claude"
echo "   Try: /engage <target> bugbounty"
echo "   Or:  /oneshot <target>"
echo "   Or:  /ctf <challenge> web"
