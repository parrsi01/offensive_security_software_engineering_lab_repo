# ☠️ DOOMSDAY — Complete Setup Guide

## Prerequisites

```bash
# Node.js 18+ required
node --version   # must be 18+
# If not: https://nodejs.org or: nvm install 18

# Anthropic API key OR Claude Pro/Max subscription
# Get key: https://console.anthropic.com
```

---

## Step 1 — Install Claude Code CLI

```bash
npm install -g @anthropic-ai/claude-code
```

Verify:
```bash
claude --version
```

---

## Step 2 — Set Your API Key

```bash
# Option A: Environment variable (recommended)
export ANTHROPIC_API_KEY="sk-ant-YOUR-KEY-HERE"

# Make it permanent:
echo 'export ANTHROPIC_API_KEY="sk-ant-YOUR-KEY-HERE"' >> ~/.bashrc
source ~/.bashrc
# (Use ~/.zshrc if you use zsh)
```

If using Claude Pro/Max subscription: run `claude` and follow the browser login flow instead.

---

## Step 3 — Extract and Install DOOMSDAY

```bash
# Unzip the package
unzip doomsday-agent.zip
cd doomsday-agent

# Make install script executable
chmod +x install.sh

# Run installer (copies to ~/.claude/ globally)
./install.sh
```

What the installer does:
- Backs up any existing `~/.claude/CLAUDE.md` and `~/.claude/settings.json`
- Installs the DOOMSDAY constitution as your global CLAUDE.md
- Installs all agents to `~/.claude/agents/`
- Installs all skills to `~/.claude/skills/`
- Installs all slash commands to `~/.claude/commands/`

---

## Step 4 — Verify Installation

```bash
ls ~/.claude/agents/     # Should show: orchestrator, recon, webapp, network, appsec, reporter
ls ~/.claude/skills/     # Should show: pentest, bugbounty, hardening
ls ~/.claude/commands/   # Should show: engage, scope, oneshot, report, ctf, harden
cat ~/.claude/CLAUDE.md  # Should show DOOMSDAY constitution
```

---

## Step 5 — Launch

```bash
# From ANYWHERE on your machine:
claude

# Or from your pentest working directory:
mkdir ~/engagements && cd ~/engagements
claude
```

---

## Step 6 — First Run Test

In the Claude Code REPL, try:

```
/engage hackthebox bugbounty
```

Or to test it's loaded correctly:
```
What agents do you have available?
```

It should list: orchestrator, recon, webapp, network, appsec, reporter.

---

## Step 7 — Install Pentest Tools (Kali/Ubuntu/Debian)

```bash
# Core tools
sudo apt update && sudo apt install -y \
  nmap masscan nikto gobuster \
  sqlmap hydra john hashcat \
  wireshark tcpdump netcat-openbsd \
  smbclient enum4linux \
  python3-pip git curl wget jq

# Go-based tools (requires Go: https://go.dev/dl/)
go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go install github.com/projectdiscovery/httpx/cmd/httpx@latest
go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
go install github.com/projectdiscovery/katana/cmd/katana@latest
go install github.com/ffuf/ffuf/v2@latest
go install github.com/lc/gau/v2/cmd/gau@latest
go install github.com/tomnomnom/waybackurls@latest

# Python tools
pip3 install impacket bloodhound-python

# Metasploit
curl https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb > msfinstall
chmod 755 msfinstall && ./msfinstall

# Wordlists
sudo apt install seclists -y

# Privilege escalation scripts
wget -q https://github.com/carlospolop/PEASS-ng/releases/latest/download/linpeas.sh
wget -q https://github.com/carlospolop/PEASS-ng/releases/latest/download/winPEASx64.exe

# SAST tools
pip3 install semgrep bandit gitleaks
npm install -g eslint

echo "✅ Tools installed"
```

---

## Usage Reference

### Slash Commands
```
/engage <target> <type>    Start a new engagement
/oneshot <target>          Full assessment in one shot
/scope                     Authorization gate check
/ctf <challenge> <cat>     CTF challenge mode
/harden [path]             Security hardening mode
/report                    Write professional report
```

### Natural Language (just talk to it)
```
"Run passive recon on target.com"
"Test this endpoint for SQLi: /api/search?q="
"Help me exploit this HackTheBox machine"
"Review this Python code for security issues"
"Write a bug bounty report for this IDOR I found"
"What's the privesc path from www-data?"
"Generate a nuclei command for this target"
```

### Model Selection
```bash
# Use Opus for complex multi-step reasoning (slower, smarter)
claude --model claude-opus-4-6

# Use Sonnet for most tasks (fast, smart)
claude --model claude-sonnet-4-6

# Set default model
claude config set defaultModel claude-opus-4-6
```

---

## Codex CLI Setup (Optional Parallel)

```bash
# Install
npm install -g @openai/codex

# Set key
export OPENAI_API_KEY="sk-YOUR-KEY-HERE"

# Create config
mkdir -p ~/.codex

# Copy content from CODEX-CONFIG.md in this package into:
# ~/.codex/instructions.md  (the instructions block)
# ~/.codex/AGENTS.md        (the agents block)
# ~/.codex/config.json      (the config block)

# Launch
codex
```

---

## Troubleshooting

**"command not found: claude"**
```bash
npm install -g @anthropic-ai/claude-code
# Or check npm global path:
npm config get prefix   # Should be in $PATH
```

**Agent not loading**
```bash
ls ~/.claude/agents/   # Verify files exist
claude --debug         # Launch with debug output
```

**Permission errors on scan tools**
```bash
# Some tools (masscan, nmap UDP) need sudo
sudo nmap -sU ...
sudo masscan ...
```

**CLAUDE.md not loading**
```bash
# Verify it's in the right location
cat ~/.claude/CLAUDE.md
# Try launching from any directory
cd ~ && claude
```
