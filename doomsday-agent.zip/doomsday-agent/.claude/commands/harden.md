# /harden

Security hardening and review mode.

**Usage:** `/harden <target>` where target is app, server, or codebase path

## Instructions

1. Identify what's being hardened (web app / server / container / code)
2. Run appropriate automated checks (semgrep, gitleaks, nuclei, etc.)
3. Manual review against OWASP ASVS Level 1
4. Check security headers
5. Check dependency vulnerabilities
6. Produce prioritized hardening checklist
7. Implement fixes if code access available
