# /report

Generate professional security report.

**Usage:** `/report` then describe your finding

## Instructions

Delegate to **reporter** agent. Collect:
- Vuln type
- Affected endpoint
- Steps to reproduce
- Impact observed
- Target program/client

Output: complete submission-ready report.
Save to: `reports/<target>-<vulntype>-<date>.md`
