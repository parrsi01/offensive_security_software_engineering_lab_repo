# /ctf

CTF challenge mode. Full exploit chain, flags are the goal.

**Usage:** `/ctf <challenge-name> <category>`

Categories: `web` | `pwn` | `crypto` | `forensics` | `misc` | `reverse`

## Instructions

1. Analyze the challenge
2. Enumerate all attack surface
3. Identify vulnerability class
4. Develop exploit step by step
5. Extract flag
6. Write a clean writeup to `notes/ctf/<challenge>.md`
