# /scope

Authorization gate. Run before ANY active testing.

## Instructions

Ask user to confirm ALL:
1. ✅ Target authorized? (Program URL / contract / own system)
2. ✅ This specific action is in scope?
3. ✅ Within testing time window?
4. ✅ Rate limits understood?

If any NO → STOP. Do not proceed.
If all YES → log "Scope confirmed [timestamp]" and proceed.
