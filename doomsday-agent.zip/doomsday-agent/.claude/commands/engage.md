# /engage

**Usage:** `/engage <target> <type>`

Types: `bugbounty` | `pentest` | `ctf` | `hackathon` | `harden`

## Instructions

1. Ask user to confirm authorization for the target
2. Create engagement folder: `targets/<target>/`
3. Ask for scope details (in-scope, out-of-scope, rules)
4. Write `targets/<target>/scope.md`
5. Delegate initial recon to **recon** agent (passive phase)
6. Present attack surface summary
7. Ask: "Proceed to active testing?"
8. If yes → begin systematic testing using appropriate agents
