# /oneshot

Full engagement in one shot. Plan → execute → report.

**Usage:** `/oneshot <target>`

## Instructions

1. Confirm authorization for target
2. Print full attack plan with phases
3. Execute each phase sequentially:
   - Passive recon (recon agent)
   - Active recon (recon agent, after scope confirm)
   - Web testing (webapp agent)
   - Network testing if applicable (network agent)
   - Exploitation of confirmed vulns (document, don't auto-exploit)
4. Compile all findings with severity ratings
5. Generate professional report (reporter agent)
6. Save to `reports/<target>-<date>.md`
