---
name: hardening
description: Security hardening for applications, servers, containers, and cloud environments. CIS benchmarks, OWASP ASVS compliance, Docker/K8s hardening, web server config. Auto-triggers on "harden", "secure", "compliance", "CIS", "NIST".
allowed-tools: Bash, Read, Write, Edit, WebSearch
version: 1.0.0
---

# 🔒 DOOMSDAY Hardening Skill

## Web Application (OWASP Headers)

```nginx
# nginx — add to server block
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains; preload" always;
add_header X-Frame-Options "DENY" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header Permissions-Policy "camera=(), microphone=(), geolocation=()" always;
add_header Content-Security-Policy "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none';" always;

# Disable server tokens
server_tokens off;

# TLS hardening
ssl_protocols TLSv1.2 TLSv1.3;
ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384;
ssl_prefer_server_ciphers off;
ssl_session_timeout 1d;
ssl_session_cache shared:SSL:50m;
ssl_stapling on;
ssl_stapling_verify on;
```

## Docker Hardening

```dockerfile
# Use minimal base image
FROM python:3.12-slim-bullseye

# Run as non-root
RUN addgroup --system app && adduser --system --ingroup app app
USER app

# Read-only filesystem where possible
# Set in docker-compose:
# read_only: true
# tmpfs: ["/tmp", "/var/run"]

# Don't store secrets in ENV — use secrets at runtime
# BAD: ENV API_KEY=secret123
# GOOD: mount via Docker secrets or read from vault at runtime

# Scan image
# docker scout cves IMAGE:TAG
# trivy image IMAGE:TAG
```

```yaml
# docker-compose hardening
services:
  app:
    image: myapp:latest
    read_only: true
    tmpfs:
      - /tmp
    security_opt:
      - no-new-privileges:true
    cap_drop:
      - ALL
    cap_add:
      - NET_BIND_SERVICE  # only if needs port <1024
    user: "1000:1000"
    environment:
      - NODE_ENV=production
```

## Linux Server (CIS Level 1 Quick Wins)

```bash
# Disable unused services
systemctl disable avahi-daemon cups bluetooth 2>/dev/null

# SSH hardening — /etc/ssh/sshd_config
cat >> /etc/ssh/sshd_config << 'EOF'
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
AuthorizedKeysFile .ssh/authorized_keys
X11Forwarding no
AllowTcpForwarding no
MaxAuthTries 3
LoginGraceTime 20
Protocol 2
EOF
systemctl restart sshd

# Firewall baseline
ufw default deny incoming
ufw default allow outgoing
ufw allow ssh
ufw allow 443/tcp
ufw enable

# Automatic security updates
apt install unattended-upgrades -y
dpkg-reconfigure --priority=low unattended-upgrades

# Auditd logging
apt install auditd -y
auditctl -w /etc/passwd -p wa -k user-modify
auditctl -w /etc/sudoers -p wa -k sudoers-modify
auditctl -w /var/log/auth.log -p r -k auth-log-read
```

## Secrets Management

```bash
# Never do this:
export DB_PASSWORD="mysecret"   # In shell history
DB_PASSWORD=mysecret python app.py  # In process list

# Do this instead:
# Option 1: .env file (NOT committed to git)
python-dotenv or similar library

# Option 2: AWS Secrets Manager
aws secretsmanager get-secret-value --secret-id prod/db/password

# Option 3: HashiCorp Vault
vault kv get secret/db/password

# Scan for committed secrets
gitleaks detect --source . --log-opts="--all"
```

## Dependency Security

```bash
# Python
pip install pip-audit
pip-audit --requirement requirements.txt

# Node
npm audit --audit-level=moderate
npx snyk test

# Go
govulncheck ./...

# Automate: add to CI/CD pipeline
# GitHub: Dependabot alerts (free, enable in repo settings)
# Snyk: free tier available
```
