---
name: bugbounty
description: Bug bounty hunting methodology optimized for fast, high-impact findings. Covers program selection, recon strategy, prioritized testing, and submission. Auto-triggers on "bug bounty", "HackerOne", "Bugcrowd", "bounty hunting".
allowed-tools: Bash, Read, Write, Edit, WebSearch, WebFetch
version: 1.0.0
---

# 💰 DOOMSDAY Bug Bounty Skill

## Program Selection Strategy

**High-value targets:**
- Wide scope (*.company.com) > single domain
- High max bounty > low max bounty
- New programs (less competition) > mature programs
- Recently updated scope (new assets = new vulns)
- Use: https://hackerone.com/programs | https://bugcrowd.com/programs

## Speed-Optimized Recon

```bash
# 1. Subdomain explosion (run in parallel)
subfinder -d $TARGET -all -o subs.txt &
amass enum --passive -d $TARGET >> subs.txt &
curl -s "https://crt.sh/?q=%25.$TARGET&output=json" | \
  jq -r '.[].name_value' | sed 's/\*\.//g' >> subs.txt &
wait
sort -u subs.txt > unique-subs.txt

# 2. Resolve + find live web servers
cat unique-subs.txt | dnsx -silent | \
  httpx -silent -status-code -title -tech-detect \
  -o live-hosts.txt

# 3. Grab ALL URLs for parameter hunting
cat live-hosts.txt | cut -d' ' -f1 | gau --threads 5 > all-urls.txt
cat live-hosts.txt | cut -d' ' -f1 | waybackurls >> all-urls.txt
sort -u all-urls.txt > dedup-urls.txt

# 4. Find juicy parameters
cat dedup-urls.txt | grep "=" | \
  grep -iE "url=|redirect=|file=|path=|page=|src=|dest=|return=|uri=|load=" \
  > juicy-params.txt  # SSRF/redirect candidates

cat dedup-urls.txt | grep "=" | \
  grep -iE "id=|user=|account=|uid=|order=|invoice=" \
  > idor-candidates.txt
```

## High-Impact Attack Priority

```
1. SSRF → Cloud metadata = Critical
2. SQLi (unauth) → DB dump = Critical
3. IDOR → Other user data = High/Critical
4. Auth bypass → Admin access = Critical
5. Stored XSS → Session hijack = High
6. IDOR (auth) → Limited data = Medium/High
7. Open redirect → Phishing = Low/Medium
8. Info disclosure → API keys = High/Critical
```

## Scope Rules (Always Check)

```bash
# Read full program policy before ANY testing
# Check: is subdomain in scope?
# Check: is this functionality in scope?
# Check: are there rate limits on automated scanning?
# Check: are there systems to explicitly avoid?
# Check: disclosure policy (90 days? coordinated?)

# Common exclusions: payment systems, 3rd party, CDN infra
```

## Submission Checklist

Before submitting:
```
[ ] Reproducible on demand
[ ] No real user data used in PoC (use own account)
[ ] Severity rated using CVSS or program's scale
[ ] Clear impact statement
[ ] Remediation recommended
[ ] Not already reported (check disclosed reports)
[ ] Within scope
```
